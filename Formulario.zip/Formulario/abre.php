<?php
$conexion = new mysqli("awardspace", "4586180_oliver", "Z%D+q%_36KC0:k64", "4586180_oliver");
if ($conexion){
    echo "la gestion fue exitosa";
}else{
    echo "Fallo la gestion";
}
?>